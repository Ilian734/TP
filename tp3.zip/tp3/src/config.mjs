export default {
  development: {
    type: 'development',
    port: 3000,
    mongodb: 'mongodb+srv://ilian:0000@cluster0.ujaaysz.mongodb.net/tp3?retryWrites=true&w=majority'
  },
 
  production: {
    type: 'production',
    port: 3000,
    mongodb: 'mongodb+srv://ilian:0000@cluster0.ujaaysz.mongodb.net/tp3?retryWrites=true&w=majority'
  }
};
